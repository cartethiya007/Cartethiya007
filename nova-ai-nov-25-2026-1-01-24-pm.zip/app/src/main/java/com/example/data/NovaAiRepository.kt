package com.example.data

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "NovaAiRepository"
private const val MODEL_NAME = "gemini-3.8-flash"
private const val MAX_INLINE_AUDIO_BYTES = 20 * 1024 * 1024 // 20 MB limit
private const val REQUEST_TIMEOUT_MS = 60_000L

class NovaAiRepository {

    private val modelsByPersonality = ConcurrentHashMap<PersonalityMode, GenerativeModel>()

    private fun modelFor(personality: PersonalityMode): GenerativeModel {
        return modelsByPersonality.getOrPut(personality) {
            Firebase.ai.generativeModel(
                modelName = MODEL_NAME,
                systemInstruction = content {
                    text(personality.buildSystemPrompt())
                }
            )
        }
    }

    fun streamReply(
        history: List<ChatMessage>,
        personality: PersonalityMode,
        textPrompt: String? = null,
        audioBytes: ByteArray? = null,
        audioMimeType: String = "audio/mp4"
    ): Flow<String> = flow {
        require(!textPrompt.isNullOrBlank() || audioBytes != null) {
            "Either textPrompt or audioBytes must be provided."
        }
        if (audioBytes != null && audioBytes.size > MAX_INLINE_AUDIO_BYTES) {
            throw IllegalArgumentException("Voice recording exceeds the 20 MB limit.")
        }

        val contents = buildList<Content> {
            history
                .filter { !it.isError && it.text.isNotBlank() }
                .forEach { message ->
                    val role = if (message.role == ChatRole.ASSISTANT) "model" else "user"
                    add(
                        content(role = role) {
                            text(message.text)
                        }
                    )
                }

            add(
                content(role = "user") {
                    if (audioBytes != null) {
                        inlineData(audioBytes, audioMimeType)
                        text("Respond to what the user said in this voice message.")
                    } else {
                        text(textPrompt.orEmpty().trim())
                    }
                }
            )
        }

        val activeModel = modelFor(personality)

        withTimeout(REQUEST_TIMEOUT_MS) {
            val accumulated = StringBuilder()
            activeModel.generateContentStream(contents).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
            if (accumulated.isBlank()) {
                Log.w(TAG, "Gemini returned an empty stream.")
            }
        }
    }
}
