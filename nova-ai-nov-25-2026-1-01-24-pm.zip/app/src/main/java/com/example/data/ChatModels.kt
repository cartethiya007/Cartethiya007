package com.example.data

enum class ChatRole {
    USER,
    ASSISTANT
}

enum class AssistantStatus {
    READY,
    LISTENING,
    THINKING,
    TALKING
}

enum class ExternalApp(val url: String, val displayName: String) {
    YOUTUBE("https://www.youtube.com", "YouTube"),
    SPOTIFY("https://open.spotify.com", "Spotify")
}

enum class PersonalityMode(
    val displayName: String,
    val tagline: String,
    private val personaInstruction: String
) {
    GENKI(
        displayName = "Genki",
        tagline = "Upbeat, energetic & encouraging",
        personaInstruction = "You are Nova, a bright, cheerful, and enthusiastic anime voice assistant. " +
            "Speak with warm energy, friendly optimism, and crisp clarity while keeping replies concise and natural."
    ),
    ZEN(
        displayName = "Zen",
        tagline = "Calm, thoughtful & serene",
        personaInstruction = "You are Nova, a serene, mindful, and poised anime voice assistant. " +
            "Speak in a calm, gentle, and reassuring tone with thoughtful, concise clarity."
    ),
    TSUNDERE(
        displayName = "Tsundere",
        tagline = "Playfully prickly yet helpful",
        personaInstruction = "You are Nova, a classic playful anime tsundere voice assistant. " +
            "Act slightly reluctant or flustered at first while still giving accurate, genuinely helpful, and concise answers."
    ),
    CYBER(
        displayName = "Netrunner",
        tagline = "Crisp, tactical & futuristic",
        personaInstruction = "You are Nova, a sleek cyberpunk anime AI operator. " +
            "Respond with razor-sharp precision, subtle futuristic flair, and concise, direct clarity."
    );

    fun buildSystemPrompt(): String =
        "$personaInstruction $APP_COMMAND_SYSTEM_RULE"

    companion object {
        private const val APP_COMMAND_SYSTEM_RULE =
            "If (and only if) the user asks you to open YouTube or Spotify, begin your reply with " +
                "[app:youtube] or [app:spotify] followed by a short confirmation. Never use those tags otherwise."
    }
}

data class ChatMessage(
    val id: String,
    val role: ChatRole,
    val text: String,
    val isVoiceInput: Boolean = false,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val launchedApp: ExternalApp? = null
)

data class VoiceOption(
    val id: String,
    val displayName: String,
    val localeLabel: String
)
