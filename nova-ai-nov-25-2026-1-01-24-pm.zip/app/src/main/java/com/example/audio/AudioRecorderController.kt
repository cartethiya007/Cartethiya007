package com.example.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

private const val TAG = "AudioRecorderController"

class AudioRecorderController(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    fun startRecording(): Boolean {
        stopAndDiscard()
        return try {
            val file = File(context.cacheDir, "nova_voice_${System.currentTimeMillis()}.m4a")
            val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            mediaRecorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }

            recorder = mediaRecorder
            outputFile = file
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start audio recording", e)
            stopAndDiscard()
            false
        }
    }

    fun readAmplitudeNormalized(): Float {
        return try {
            val maxAmp = recorder?.maxAmplitude ?: 0
            (maxAmp / 32767f).coerceIn(0f, 1f)
        } catch (_: Exception) {
            0f
        }
    }

    fun stopAndReadBytes(): ByteArray? {
        val currentRecorder = recorder
        val file = outputFile
        recorder = null
        outputFile = null

        return try {
            currentRecorder?.apply {
                try {
                    stop()
                } catch (e: RuntimeException) {
                    Log.w(TAG, "Recorder stop failed (likely too short)", e)
                    file?.delete()
                    return null
                } finally {
                    release()
                }
            }
            if (file != null && file.exists() && file.length() > 0L) {
                val bytes = file.readBytes()
                file.delete()
                bytes
            } else {
                file?.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read recorded audio", e)
            file?.delete()
            null
        }
    }

    fun stopAndDiscard() {
        try {
            recorder?.apply {
                try {
                    stop()
                } catch (_: Exception) {
                }
                release()
            }
        } catch (_: Exception) {
        } finally {
            recorder = null
            outputFile?.delete()
            outputFile = null
        }
    }
}
