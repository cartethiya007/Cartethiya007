package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.VoiceOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

private const val TAG = "TtsController"

data class TtsState(
    val isReady: Boolean = false,
    val isSpeaking: Boolean = false,
    val voices: List<VoiceOption> = emptyList(),
    val selectedVoiceId: String? = null
)

class TtsController(context: Context) {

    private val _state = MutableStateFlow(TtsState())
    val state: StateFlow<TtsState> = _state.asStateFlow()

    private var tts: TextToSpeech? = null
    private var voiceMap: Map<String, Voice> = emptyMap()
    private var onSpeakingChanged: ((Boolean) -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureEngine()
            } else {
                Log.e(TAG, "TextToSpeech initialization failed with status=$status")
            }
        }
    }

    fun setOnSpeakingChangedListener(listener: (Boolean) -> Unit) {
        onSpeakingChanged = listener
    }

    private fun configureEngine() {
        val engine = tts ?: return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _state.update { it.copy(isSpeaking = true) }
                onSpeakingChanged?.invoke(true)
            }

            override fun onDone(utteranceId: String?) {
                _state.update { it.copy(isSpeaking = false) }
                onSpeakingChanged?.invoke(false)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _state.update { it.copy(isSpeaking = false) }
                onSpeakingChanged?.invoke(false)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _state.update { it.copy(isSpeaking = false) }
                onSpeakingChanged?.invoke(false)
            }
        })

        val available = runCatching { engine.voices }.getOrNull().orEmpty()
        val sortedVoices = available
            .filter { !it.isNetworkConnectionRequired || it.locale.language == "en" }
            .ifEmpty { available.toList() }
            .sortedWith(
                compareByDescending<Voice> { it.locale.language.equals("en", ignoreCase = true) }
                    .thenBy { it.locale.displayName }
                    .thenBy { it.name }
            )
            .take(24)

        voiceMap = sortedVoices.associateBy { it.name }
        val options = sortedVoices.mapIndexed { index, voice ->
            VoiceOption(
                id = voice.name,
                displayName = formatVoiceName(voice, index + 1),
                localeLabel = voice.locale.displayName
            )
        }

        val defaultVoice = sortedVoices.firstOrNull {
            it.locale.language.equals("en", ignoreCase = true)
        } ?: sortedVoices.firstOrNull()

        if (defaultVoice != null) {
            engine.voice = defaultVoice
        } else {
            engine.language = Locale.US
        }

        _state.update {
            it.copy(
                isReady = true,
                voices = options,
                selectedVoiceId = defaultVoice?.name
            )
        }
    }

    private fun formatVoiceName(voice: Voice, index: Int): String {
        val localeTag = voice.locale.toLanguageTag()
        val shortName = voice.name
            .substringAfterLast('#')
            .substringAfterLast('-')
            .replace("_", " ")
            .trim()
        return if (shortName.length in 2..16 && !shortName.equals("local", ignoreCase = true)) {
            "${voice.locale.displayLanguage} ($localeTag) • $shortName"
        } else {
            "${voice.locale.displayLanguage} ($localeTag) • Voice $index"
        }
    }

    fun speak(text: String) {
        val engine = tts ?: return
        if (!_state.value.isReady || text.isBlank()) return
        val utteranceId = "nova_${System.currentTimeMillis()}"
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _state.update { it.copy(isSpeaking = false) }
        onSpeakingChanged?.invoke(false)
    }

    fun selectVoice(voiceId: String): VoiceOption? {
        val engine = tts ?: return null
        val voice = voiceMap[voiceId] ?: return null
        engine.voice = voice
        _state.update { it.copy(selectedVoiceId = voiceId) }
        return _state.value.voices.firstOrNull { it.id == voiceId }
    }

    fun cycleVoice(): VoiceOption? {
        val list = _state.value.voices
        if (list.isEmpty()) return null
        val currentIdx = list.indexOfFirst { it.id == _state.value.selectedVoiceId }
        val next = list[(currentIdx + 1) % list.size]
        return selectVoice(next.id)
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        } finally {
            tts = null
        }
    }
}
