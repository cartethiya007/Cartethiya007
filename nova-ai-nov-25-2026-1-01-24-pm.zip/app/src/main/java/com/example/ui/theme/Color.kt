package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicBlack = Color(0xFF07070B)
val ObsidianSurface = Color(0xFF10101A)
val NebulaCard = Color(0xFF141422)
val ElevatedCard = Color(0xFF1B1B2E)
val UserBubbleSurface = Color(0xFF222238)
val AssistantBubbleSurface = Color(0xFF12121E)

val CyberAqua = Color(0xFF00F5D4)
val ElectricSky = Color(0xFF4CC9F0)
val SakuraMagenta = Color(0xFFF72585)
val NeonOrchid = Color(0xFFB5179E)
val DeepViolet = Color(0xFF7209B7)

val SurfaceBorder = Color(0xFF26263D)
val SubtleDivider = Color(0xFF191926)

val TextPrimary = Color(0xFFF4F4FA)
val TextSecondary = Color(0xFFA5A5C0)
val TextMuted = Color(0xFF6E6E85)
val ErrorCrimson = Color(0xFFFF5C8A)
