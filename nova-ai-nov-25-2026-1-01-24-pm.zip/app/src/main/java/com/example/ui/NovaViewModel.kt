package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.audio.AudioRecorderController
import com.example.audio.TtsController
import com.example.data.AssistantStatus
import com.example.data.ChatMessage
import com.example.data.ChatRole
import com.example.data.ExternalApp
import com.example.data.NovaAiRepository
import com.example.data.PersonalityMode
import com.example.data.VoiceOption
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "NovaViewModel"
private val APP_TAG_REGEX = Regex("""^\s*\[app:(youtube|spotify)]\s*""", RegexOption.IGNORE_CASE)

data class NovaUiState(
    val status: AssistantStatus = AssistantStatus.READY,
    val personality: PersonalityMode = PersonalityMode.GENKI,
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val micAmplitude: Float = 0f,
    val voices: List<VoiceOption> = emptyList(),
    val selectedVoiceId: String? = null,
    val isTtsReady: Boolean = false,
    val errorMessage: String? = null
) {
    val selectedVoiceLabel: String
        get() = voices.firstOrNull { it.id == selectedVoiceId }?.displayName ?: "Default Voice"
}

sealed interface NovaEffect {
    data class OpenExternalApp(val app: ExternalApp) : NovaEffect
    data class ShowMessage(val message: String) : NovaEffect
}

class NovaViewModel(application: Application) : AndroidViewModel(application) {

    private val aiRepository = NovaAiRepository()
    private val audioRecorder = AudioRecorderController(application)
    private val ttsController = TtsController(application)

    private val _uiState = MutableStateFlow(NovaUiState())
    val uiState: StateFlow<NovaUiState> = _uiState.asStateFlow()

    private val _effects = MutableSharedFlow<NovaEffect>()
    val effects: SharedFlow<NovaEffect> = _effects.asSharedFlow()

    private var amplitudeJob: Job? = null
    private var generationJob: Job? = null

    init {
        ttsController.state
            .onEach { ttsState ->
                _uiState.update { current ->
                    val nextStatus = when {
                        current.status == AssistantStatus.LISTENING ||
                            current.status == AssistantStatus.THINKING -> current.status
                        ttsState.isSpeaking -> AssistantStatus.TALKING
                        else -> AssistantStatus.READY
                    }
                    current.copy(
                        status = nextStatus,
                        voices = ttsState.voices,
                        selectedVoiceId = ttsState.selectedVoiceId,
                        isTtsReady = ttsState.isReady
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    fun updateInputText(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun selectPersonality(mode: PersonalityMode) {
        if (_uiState.value.personality == mode) return
        _uiState.update { it.copy(personality = mode) }
        viewModelScope.launch {
            val msg = getApplication<Application>().getString(
                R.string.personality_switched_template,
                mode.displayName
            )
            _effects.emit(NovaEffect.ShowMessage(msg))
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun clearChat() {
        generationJob?.cancel()
        ttsController.stop()
        _uiState.update {
            it.copy(
                messages = emptyList(),
                status = if (it.status == AssistantStatus.LISTENING) AssistantStatus.LISTENING else AssistantStatus.READY,
                errorMessage = null
            )
        }
    }

    fun stopSpeaking() {
        ttsController.stop()
    }

    fun speakMessage(text: String) {
        ttsController.speak(text)
    }

    fun cycleVoice() {
        val selected = ttsController.cycleVoice() ?: return
        val announcement = getApplication<Application>().getString(
            R.string.voice_switched_template,
            selected.displayName.substringBefore(" •")
        )
        ttsController.speak(announcement)
    }

    fun selectVoice(voiceId: String) {
        val selected = ttsController.selectVoice(voiceId) ?: return
        val announcement = getApplication<Application>().getString(
            R.string.voice_switched_template,
            selected.displayName.substringBefore(" •")
        )
        ttsController.speak(announcement)
    }

    fun startListening() {
        if (_uiState.value.status == AssistantStatus.LISTENING ||
            _uiState.value.status == AssistantStatus.THINKING
        ) {
            return
        }
        ttsController.stop()
        val started = audioRecorder.startRecording()
        if (!started) {
            val msg = getApplication<Application>().getString(R.string.error_recording_failed)
            _uiState.update { it.copy(status = AssistantStatus.READY, errorMessage = msg) }
            return
        }

        _uiState.update { it.copy(status = AssistantStatus.LISTENING, micAmplitude = 0f, errorMessage = null) }
        amplitudeJob?.cancel()
        amplitudeJob = viewModelScope.launch {
            while (true) {
                _uiState.update { it.copy(micAmplitude = audioRecorder.readAmplitudeNormalized()) }
                delay(80L)
            }
        }
    }

    fun stopListeningAndSend() {
        if (_uiState.value.status != AssistantStatus.LISTENING) return
        amplitudeJob?.cancel()
        amplitudeJob = null

        viewModelScope.launch {
            _uiState.update { it.copy(status = AssistantStatus.THINKING, micAmplitude = 0f) }
            val audioBytes = withContext(Dispatchers.IO) {
                audioRecorder.stopAndReadBytes()
            }
            if (audioBytes == null || audioBytes.isEmpty()) {
                _uiState.update {
                    it.copy(
                        status = AssistantStatus.READY,
                        errorMessage = getApplication<Application>().getString(R.string.error_recording_failed)
                    )
                }
                return@launch
            }
            sendToGemini(textPrompt = null, audioBytes = audioBytes)
        }
    }

    fun sendTextMessage(overrideText: String? = null) {
        val raw = (overrideText ?: _uiState.value.inputText).trim()
        if (raw.isEmpty() || _uiState.value.status == AssistantStatus.THINKING) return
        ttsController.stop()
        _uiState.update { it.copy(inputText = "", errorMessage = null) }
        sendToGemini(textPrompt = raw, audioBytes = null)
    }

    private fun sendToGemini(textPrompt: String?, audioBytes: ByteArray?) {
        val historySnapshot = _uiState.value.messages
        val activePersonality = _uiState.value.personality
        val userLabel = if (audioBytes != null) {
            "\uD83C\uDFA4 " + getApplication<Application>().getString(R.string.voice_message_label)
        } else {
            textPrompt.orEmpty()
        }

        val userMsg = ChatMessage(
            id = "${System.currentTimeMillis()}_u",
            role = ChatRole.USER,
            text = userLabel,
            isVoiceInput = audioBytes != null
        )
        val assistantMsgId = "${System.currentTimeMillis() + 1}_a"
        val placeholderMsg = ChatMessage(
            id = assistantMsgId,
            role = ChatRole.ASSISTANT,
            text = "",
            isStreaming = true
        )

        _uiState.update {
            it.copy(
                status = AssistantStatus.THINKING,
                messages = it.messages + userMsg + placeholderMsg,
                errorMessage = null
            )
        }

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            var latestRaw = ""
            try {
                aiRepository.streamReply(
                    history = historySnapshot,
                    personality = activePersonality,
                    textPrompt = textPrompt,
                    audioBytes = audioBytes
                ).collect { accumulated ->
                    latestRaw = accumulated
                    val displayPartial = stripStreamingCommandPrefix(accumulated)
                    _uiState.update { state ->
                        state.copy(
                            messages = state.messages.map { msg ->
                                if (msg.id == assistantMsgId) {
                                    msg.copy(text = displayPartial, isStreaming = true)
                                } else {
                                    msg
                                }
                            }
                        )
                    }
                }

                if (latestRaw.isBlank()) {
                    val emptyMsg = getApplication<Application>().getString(R.string.error_empty_response)
                    updateErrorMessage(assistantMsgId, emptyMsg)
                    return@launch
                }

                val (launchedApp, cleanReply) = extractCommand(latestRaw)
                val finalText = cleanReply.ifBlank {
                    launchedApp?.let { "Opening ${it.displayName}." }
                        ?: getApplication<Application>().getString(R.string.error_empty_response)
                }

                _uiState.update { state ->
                    state.copy(
                        status = AssistantStatus.READY,
                        messages = state.messages.map { msg ->
                            if (msg.id == assistantMsgId) {
                                msg.copy(
                                    text = finalText,
                                    isStreaming = false,
                                    launchedApp = launchedApp
                                )
                            } else {
                                msg
                            }
                        }
                    )
                }

                if (launchedApp != null) {
                    _effects.emit(NovaEffect.OpenExternalApp(launchedApp))
                }
                ttsController.speak(finalText)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini request timed out", e)
                val timeoutMsg = getApplication<Application>().getString(R.string.error_timeout)
                updateErrorMessage(assistantMsgId, timeoutMsg)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Gemini generation failed", e)
                val errorText = e.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: "Could not reach Gemini. Please check your connection and try again."
                updateErrorMessage(assistantMsgId, errorText)
            }
        }
    }

    private fun updateErrorMessage(assistantMsgId: String, message: String) {
        _uiState.update { state ->
            state.copy(
                status = AssistantStatus.READY,
                errorMessage = message,
                messages = state.messages.map { msg ->
                    if (msg.id == assistantMsgId) {
                        msg.copy(text = message, isStreaming = false, isError = true)
                    } else {
                        msg
                    }
                }
            )
        }
    }

    private fun stripStreamingCommandPrefix(raw: String): String {
        val match = APP_TAG_REGEX.find(raw)
        if (match != null) {
            return raw.removeRange(match.range)
        }
        val trimmed = raw.trimStart()
        // Hide partial `[app:...` prefix while streaming until `]` closes
        if (trimmed.startsWith("[") && !trimmed.contains("]") && trimmed.length <= 16) {
            return ""
        }
        return raw
    }

    private fun extractCommand(raw: String): Pair<ExternalApp?, String> {
        val match = APP_TAG_REGEX.find(raw) ?: return null to raw.trim()
        val appKey = match.groupValues.getOrNull(1)?.lowercase()
        val app = when (appKey) {
            "youtube" -> ExternalApp.YOUTUBE
            "spotify" -> ExternalApp.SPOTIFY
            else -> null
        }
        val cleaned = raw.removeRange(match.range).trim()
        return app to cleaned
    }

    override fun onCleared() {
        super.onCleared()
        amplitudeJob?.cancel()
        generationJob?.cancel()
        audioRecorder.stopAndDiscard()
        ttsController.shutdown()
    }
}
