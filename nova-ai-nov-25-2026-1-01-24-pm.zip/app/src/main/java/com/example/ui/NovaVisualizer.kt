package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.AssistantStatus
import com.example.data.PersonalityMode
import com.example.ui.theme.CyberAqua
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.ElectricSky
import com.example.ui.theme.NebulaCard
import com.example.ui.theme.NeonOrchid
import com.example.ui.theme.SakuraMagenta
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextSecondary

@Composable
fun NovaVisualizer(
    status: AssistantStatus,
    personality: PersonalityMode,
    micAmplitude: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "nova_visualizer")

    val basePulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = when (status) {
            AssistantStatus.LISTENING -> 1.14f
            AssistantStatus.THINKING -> 1.08f
            AssistantStatus.TALKING -> 1.11f
            AssistantStatus.READY -> 1.03f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (status) {
                    AssistantStatus.LISTENING -> 520
                    AssistantStatus.THINKING -> 700
                    AssistantStatus.TALKING -> 420
                    AssistantStatus.READY -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = if (status == AssistantStatus.READY) 0.25f else 0.45f,
        targetValue = if (status == AssistantStatus.READY) 0.45f else 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 7000),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit_rotation"
    )

    val reactiveBoost by animateFloatAsState(
        targetValue = if (status == AssistantStatus.LISTENING) micAmplitude * 0.16f else 0f,
        animationSpec = spring(stiffness = 500f),
        label = "mic_boost"
    )

    val readyColor = when (personality) {
        PersonalityMode.GENKI -> CyberAqua
        PersonalityMode.ZEN -> ElectricSky
        PersonalityMode.TSUNDERE -> SakuraMagenta
        PersonalityMode.CYBER -> NeonOrchid
    }

    val primaryRingColor by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING -> CyberAqua
            AssistantStatus.THINKING -> NeonOrchid
            AssistantStatus.TALKING -> SakuraMagenta
            AssistantStatus.READY -> readyColor
        },
        animationSpec = tween(300),
        label = "primary_ring"
    )

    val secondaryRingColor by animateColorAsState(
        targetValue = when (status) {
            AssistantStatus.LISTENING -> DeepViolet
            AssistantStatus.THINKING -> SakuraMagenta
            AssistantStatus.TALKING -> CyberAqua
            AssistantStatus.READY -> CyberAqua
        },
        animationSpec = tween(300),
        label = "secondary_ring"
    )

    val statusText = when (status) {
        AssistantStatus.READY -> "${stringResource(R.string.status_ready)} • ${personality.displayName}"
        AssistantStatus.LISTENING -> stringResource(R.string.status_listening)
        AssistantStatus.THINKING -> stringResource(R.string.status_thinking)
        AssistantStatus.TALKING -> stringResource(R.string.status_talking)
    }

    Column(
        modifier = modifier.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(204.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val scale = basePulse + reactiveBoost
                        scaleX = scale
                        scaleY = scale
                    }
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val outerRadius = size.minDimension * 0.46f
                val innerRadius = size.minDimension * 0.405f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryRingColor.copy(alpha = glowAlpha * 0.34f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = outerRadius * 1.18f
                    ),
                    radius = outerRadius * 1.18f,
                    center = center
                )

                drawCircle(
                    color = primaryRingColor.copy(alpha = glowAlpha),
                    radius = outerRadius,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )

                drawCircle(
                    color = secondaryRingColor.copy(alpha = (glowAlpha * 0.85f).coerceIn(0.2f, 1f)),
                    radius = innerRadius,
                    center = center,
                    style = Stroke(width = 1.75.dp.toPx())
                )

                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.Transparent,
                            primaryRingColor,
                            secondaryRingColor,
                            Color.Transparent
                        )
                    ),
                    startAngle = rotationAngle,
                    sweepAngle = 110f,
                    useCenter = false,
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }

            Box(
                modifier = Modifier
                    .size(144.dp)
                    .clip(CircleShape)
                    .background(NebulaCard)
                    .border(
                        width = 2.5.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(primaryRingColor, secondaryRingColor)
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_nova_avatar),
                    contentDescription = stringResource(R.string.nova_avatar_cd),
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(NebulaCard)
                .border(1.dp, SurfaceBorder, RoundedCornerShape(999.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(primaryRingColor)
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
        }
    }
}
