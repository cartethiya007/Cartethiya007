package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NovaDarkColorScheme = darkColorScheme(
    primary = CyberAqua,
    onPrimary = CosmicBlack,
    primaryContainer = ElevatedCard,
    onPrimaryContainer = CyberAqua,
    secondary = ElectricSky,
    onSecondary = CosmicBlack,
    secondaryContainer = UserBubbleSurface,
    onSecondaryContainer = TextPrimary,
    tertiary = SakuraMagenta,
    onTertiary = TextPrimary,
    tertiaryContainer = NeonOrchid,
    onTertiaryContainer = TextPrimary,
    background = CosmicBlack,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = NebulaCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    outlineVariant = SubtleDivider,
    error = ErrorCrimson,
    onError = CosmicBlack
)

@Composable
fun NovaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NovaDarkColorScheme,
        typography = NovaTypography,
        content = content
    )
}
