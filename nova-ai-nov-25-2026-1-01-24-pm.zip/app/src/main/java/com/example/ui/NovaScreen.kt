package com.example.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.AssistantStatus
import com.example.data.ChatMessage
import com.example.data.ChatRole
import com.example.data.ExternalApp
import com.example.data.PersonalityMode
import com.example.data.VoiceOption
import com.example.ui.theme.AssistantBubbleSurface
import com.example.ui.theme.CosmicBlack
import com.example.ui.theme.CyberAqua
import com.example.ui.theme.ElectricSky
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.NebulaCard
import com.example.ui.theme.NeonOrchid
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SakuraMagenta
import com.example.ui.theme.SubtleDivider
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.UserBubbleSurface
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaScreen(
    viewModel: NovaViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    var showVoiceSheet by remember { mutableStateOf(false) }

    val micPermissionMessage = stringResource(R.string.mic_permission_needed)
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startListening()
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar(micPermissionMessage)
            }
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.effects.collect { effect ->
            when (effect) {
                is NovaEffect.OpenExternalApp -> {
                    openExternalUrl(context, effect.app) { failMsg ->
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(failMsg)
                        }
                    }
                }
                is NovaEffect.ShowMessage -> {
                    snackbarHostState.showSnackbar(effect.message)
                }
            }
        }
    }

    val onMicClick: () -> Unit = {
        if (uiState.status == AssistantStatus.LISTENING) {
            viewModel.stopListeningAndSend()
        } else {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                viewModel.startListening()
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    val copiedMessage = stringResource(R.string.copied_toast)
    val onCopyText: (String) -> Unit = { text ->
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Nova AI", text))
        coroutineScope.launch {
            snackbarHostState.showSnackbar(copiedMessage)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(CosmicBlack),
        containerColor = CosmicBlack,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            NovaHeader(
                status = uiState.status,
                personality = uiState.personality,
                hasMessages = uiState.messages.isNotEmpty(),
                voiceLabel = uiState.selectedVoiceLabel,
                onSelectPersonality = viewModel::selectPersonality,
                onVoiceClick = {
                    if (uiState.voices.isNotEmpty()) {
                        showVoiceSheet = true
                    } else {
                        viewModel.cycleVoice()
                    }
                },
                onStopSpeaking = viewModel::stopSpeaking,
                onClearChat = viewModel::clearChat
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(CosmicBlack, ObsidianSurface, CosmicBlack)
                    )
                )
        ) {
            val isExpanded = maxWidth >= 840.dp

            if (isExpanded) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(340.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        NovaVisualizer(
                            status = uiState.status,
                            personality = uiState.personality,
                            micAmplitude = uiState.micAmplitude
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .navigationBarsPadding()
                            .imePadding()
                    ) {
                        ChatArea(
                            messages = uiState.messages,
                            status = uiState.status,
                            errorMessage = uiState.errorMessage,
                            onDismissError = viewModel::dismissError,
                            onQuickPrompt = { viewModel.sendTextMessage(it) },
                            onCopy = onCopyText,
                            onSpeak = viewModel::speakMessage,
                            onLaunchApp = { app ->
                                openExternalUrl(context, app) { failMsg ->
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(failMsg)
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        ComposerBar(
                            inputText = uiState.inputText,
                            status = uiState.status,
                            onInputChange = viewModel::updateInputText,
                            onSend = { viewModel.sendTextMessage() },
                            onMicClick = onMicClick
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 680.dp)
                        .align(Alignment.Center)
                        .navigationBarsPadding()
                        .imePadding(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    NovaVisualizer(
                        status = uiState.status,
                        personality = uiState.personality,
                        micAmplitude = uiState.micAmplitude,
                        modifier = Modifier.fillMaxWidth()
                    )

                    ChatArea(
                        messages = uiState.messages,
                        status = uiState.status,
                        errorMessage = uiState.errorMessage,
                        onDismissError = viewModel::dismissError,
                        onQuickPrompt = { viewModel.sendTextMessage(it) },
                        onCopy = onCopyText,
                        onSpeak = viewModel::speakMessage,
                        onLaunchApp = { app ->
                            openExternalUrl(context, app) { failMsg ->
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar(failMsg)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    )

                    ComposerBar(
                        inputText = uiState.inputText,
                        status = uiState.status,
                        onInputChange = viewModel::updateInputText,
                        onSend = { viewModel.sendTextMessage() },
                        onMicClick = onMicClick
                    )
                }
            }
        }
    }

    if (showVoiceSheet) {
        ModalBottomSheet(
            onDismissRequest = { showVoiceSheet = false },
            containerColor = ObsidianSurface,
            contentColor = TextPrimary
        ) {
            VoicePickerSheetContent(
                voices = uiState.voices,
                selectedVoiceId = uiState.selectedVoiceId,
                onCycleVoice = {
                    viewModel.cycleVoice()
                },
                onSelectVoice = { id ->
                    viewModel.selectVoice(id)
                    showVoiceSheet = false
                }
            )
        }
    }
}

@Composable
private fun NovaHeader(
    status: AssistantStatus,
    personality: PersonalityMode,
    hasMessages: Boolean,
    voiceLabel: String,
    onSelectPersonality: (PersonalityMode) -> Unit,
    onVoiceClick: () -> Unit,
    onStopSpeaking: () -> Unit,
    onClearChat: () -> Unit
) {
    var personalityMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CosmicBlack)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = CyberAqua,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.header_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberAqua
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                AnimatedVisibility(
                    visible = status == AssistantStatus.TALKING,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    IconButton(
                        onClick = onStopSpeaking,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("stop_speaking_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VolumeOff,
                            contentDescription = stringResource(R.string.stop_speaking_cd),
                            tint = SakuraMagenta
                        )
                    }
                }

                AnimatedVisibility(
                    visible = hasMessages,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    IconButton(
                        onClick = onClearChat,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = stringResource(R.string.clear_chat_cd),
                            tint = TextSecondary
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box {
                val accent = personalityAccentColor(personality)
                Surface(
                    onClick = { personalityMenuExpanded = true },
                    shape = RoundedCornerShape(999.dp),
                    color = NebulaCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("personality_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = personalityIcon(personality),
                            contentDescription = stringResource(R.string.personality_button_cd),
                            tint = accent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = personalityLabel(personality),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = Icons.Filled.ArrowDropDown,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = personalityMenuExpanded,
                    onDismissRequest = { personalityMenuExpanded = false },
                    containerColor = ObsidianSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                    modifier = Modifier.testTag("personality_menu")
                ) {
                    Text(
                        text = stringResource(R.string.personality_picker_title),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                    PersonalityMode.entries.forEach { mode ->
                        val isSelected = mode == personality
                        val modeAccent = personalityAccentColor(mode)
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = personalityLabel(mode),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isSelected) modeAccent else TextPrimary
                                    )
                                    Text(
                                        text = personalityDescription(mode),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = personalityIcon(mode),
                                    contentDescription = null,
                                    tint = modeAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = if (isSelected) {
                                {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Selected",
                                        tint = modeAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            } else {
                                null
                            },
                            onClick = {
                                personalityMenuExpanded = false
                                onSelectPersonality(mode)
                            },
                            modifier = Modifier.testTag("personality_option_${mode.name.lowercase()}")
                        )
                    }
                }
            }

            Surface(
                onClick = onVoiceClick,
                shape = RoundedCornerShape(999.dp),
                color = NebulaCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier
                    .weight(1f, fill = false)
                    .minimumInteractiveComponentSize()
                    .testTag("voice_selector_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.RecordVoiceOver,
                        contentDescription = stringResource(R.string.select_voice_cd),
                        tint = ElectricSky,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = voiceLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        HorizontalDivider(color = SubtleDivider, thickness = 1.dp)
    }
}

@Composable
private fun personalityLabel(mode: PersonalityMode): String = when (mode) {
    PersonalityMode.GENKI -> stringResource(R.string.personality_genki_name)
    PersonalityMode.ZEN -> stringResource(R.string.personality_zen_name)
    PersonalityMode.TSUNDERE -> stringResource(R.string.personality_tsundere_name)
    PersonalityMode.CYBER -> stringResource(R.string.personality_cyber_name)
}

@Composable
private fun personalityDescription(mode: PersonalityMode): String = when (mode) {
    PersonalityMode.GENKI -> stringResource(R.string.personality_genki_desc)
    PersonalityMode.ZEN -> stringResource(R.string.personality_zen_desc)
    PersonalityMode.TSUNDERE -> stringResource(R.string.personality_tsundere_desc)
    PersonalityMode.CYBER -> stringResource(R.string.personality_cyber_desc)
}

private fun personalityIcon(mode: PersonalityMode): ImageVector = when (mode) {
    PersonalityMode.GENKI -> Icons.Filled.Bolt
    PersonalityMode.ZEN -> Icons.Filled.SelfImprovement
    PersonalityMode.TSUNDERE -> Icons.Filled.Favorite
    PersonalityMode.CYBER -> Icons.Filled.Memory
}

private fun personalityAccentColor(mode: PersonalityMode): Color = when (mode) {
    PersonalityMode.GENKI -> CyberAqua
    PersonalityMode.ZEN -> ElectricSky
    PersonalityMode.TSUNDERE -> SakuraMagenta
    PersonalityMode.CYBER -> NeonOrchid
}

@Composable
private fun ChatArea(
    messages: List<ChatMessage>,
    status: AssistantStatus,
    errorMessage: String?,
    onDismissError: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onCopy: (String) -> Unit,
    onSpeak: (String) -> Unit,
    onLaunchApp: (ExternalApp) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, messages.lastOrNull()?.text) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Box(modifier = modifier) {
        if (messages.isEmpty()) {
            EmptyChatState(
                onQuickPrompt = onQuickPrompt,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chat_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(
                        message = message,
                        onCopy = onCopy,
                        onSpeak = onSpeak,
                        onLaunchApp = onLaunchApp
                    )
                }

                if (status == AssistantStatus.THINKING && messages.lastOrNull()?.text.isNullOrEmpty()) {
                    item(key = "loading_indicator") {
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = CyberAqua
                            )
                            Text(
                                text = stringResource(R.string.status_thinking),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .fillMaxWidth(),
                color = ElevatedCard,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErrorCrimson,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismissError,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Dismiss error",
                            tint = ErrorCrimson
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChatState(
    onQuickPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val promptFact = stringResource(R.string.chip_anime_fact)
    val promptYouTube = stringResource(R.string.chip_open_youtube)
    val promptSpotify = stringResource(R.string.chip_open_spotify)

    Column(
        modifier = modifier.padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.empty_title),
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.empty_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            QuickSuggestionChip(
                label = promptFact,
                onClick = { onQuickPrompt(promptFact) }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            QuickSuggestionChip(
                label = promptYouTube,
                onClick = { onQuickPrompt(promptYouTube) }
            )
            QuickSuggestionChip(
                label = promptSpotify,
                onClick = { onQuickPrompt(promptSpotify) }
            )
        }
    }
}

@Composable
private fun QuickSuggestionChip(
    label: String,
    onClick: () -> Unit
) {
    AssistChip(
        onClick = onClick,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = TextPrimary
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = CyberAqua,
                modifier = Modifier.size(16.dp)
            )
        },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = NebulaCard
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
        shape = RoundedCornerShape(999.dp),
        modifier = Modifier.minimumInteractiveComponentSize()
    )
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    onCopy: (String) -> Unit,
    onSpeak: (String) -> Unit,
    onLaunchApp: (ExternalApp) -> Unit
) {
    if (message.role == ChatRole.ASSISTANT && message.text.isBlank() && message.isStreaming) {
        return
    }

    val isUser = message.role == ChatRole.USER
    val containerColor = when {
        message.isError -> ElevatedCard
        isUser -> UserBubbleSurface
        else -> AssistantBubbleSurface
    }
    val borderColor = when {
        message.isError -> ErrorCrimson.copy(alpha = 0.65f)
        isUser -> Color.Transparent
        else -> SurfaceBorder
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = containerColor,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 18.dp
            ),
            border = if (borderColor != Color.Transparent) {
                androidx.compose.foundation.BorderStroke(1.dp, borderColor)
            } else {
                null
            },
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (message.isError) ErrorCrimson else TextPrimary
                )

                if (message.launchedApp != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        onClick = { onLaunchApp(message.launchedApp) },
                        color = ElevatedCard,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricSky.copy(alpha = 0.5f)),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OpenInNew,
                                contentDescription = null,
                                tint = ElectricSky,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Opened ${message.launchedApp.displayName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricSky
                            )
                        }
                    }
                }

                if (!message.isStreaming && message.text.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!isUser && !message.isError) {
                            BubbleActionChip(
                                icon = Icons.AutoMirrored.Filled.VolumeUp,
                                label = stringResource(R.string.btn_speak),
                                tint = ElectricSky,
                                onClick = { onSpeak(message.text) }
                            )
                        }
                        BubbleActionChip(
                            icon = Icons.Filled.ContentCopy,
                            label = stringResource(R.string.btn_copy),
                            tint = CyberAqua,
                            onClick = { onCopy(message.text) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BubbleActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(ElevatedCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = tint
        )
    }
}

@Composable
private fun ComposerBar(
    inputText: String,
    status: AssistantStatus,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit
) {
    val isListening = status == AssistantStatus.LISTENING
    val isThinking = status == AssistantStatus.THINKING

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CosmicBlack)
    ) {
        HorizontalDivider(color = SubtleDivider, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = onInputChange,
                placeholder = {
                    Text(
                        text = stringResource(R.string.input_placeholder),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                singleLine = true,
                enabled = !isListening,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NebulaCard,
                    unfocusedContainerColor = NebulaCard,
                    disabledContainerColor = NebulaCard.copy(alpha = 0.5f),
                    focusedBorderColor = ElectricSky,
                    unfocusedBorderColor = SurfaceBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = CyberAqua
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("message_input")
            )

            Surface(
                onClick = onSend,
                enabled = inputText.isNotBlank() && !isThinking && !isListening,
                shape = CircleShape,
                color = if (inputText.isNotBlank() && !isThinking && !isListening) {
                    ElectricSky
                } else {
                    NebulaCard
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("send_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.btn_send),
                        tint = if (inputText.isNotBlank() && !isThinking && !isListening) {
                            CosmicBlack
                        } else {
                            TextMuted
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                onClick = onMicClick,
                enabled = !isThinking,
                shape = RoundedCornerShape(24.dp),
                color = if (isListening) SakuraMagenta else ElevatedCard,
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.5.dp,
                    color = if (isListening) SakuraMagenta else CyberAqua
                ),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("mic_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = stringResource(
                            if (isListening) R.string.btn_stop else R.string.btn_mic
                        ),
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(if (isListening) R.string.btn_stop else R.string.btn_mic),
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun VoicePickerSheetContent(
    voices: List<VoiceOption>,
    selectedVoiceId: String?,
    onCycleVoice: () -> Unit,
    onSelectVoice: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(bottom = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.voice_picker_title),
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            TextButton(onClick = onCycleVoice) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = null,
                    tint = CyberAqua,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Cycle Next",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberAqua
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(voices, key = { it.id }) { voice ->
                val isSelected = voice.id == selectedVoiceId
                Surface(
                    onClick = { onSelectVoice(voice.id) },
                    shape = RoundedCornerShape(14.dp),
                    color = if (isSelected) ElevatedCard else NebulaCard,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = if (isSelected) CyberAqua else SurfaceBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.GraphicEq,
                                contentDescription = null,
                                tint = if (isSelected) CyberAqua else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = voice.displayName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = voice.localeLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = "Selected",
                                tint = CyberAqua,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun openExternalUrl(
    context: Context,
    app: ExternalApp,
    onError: (String) -> Unit
) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(app.url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        onError(context.getString(R.string.error_open_app_failed, app.displayName))
    } catch (_: Exception) {
        onError(context.getString(R.string.error_open_app_failed, app.displayName))
    }
}
